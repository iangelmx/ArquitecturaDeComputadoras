/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vboxsrv/Downloads/Arqui/Control FULL/UC_LISTO/Unidad_De_Control_TB.vhd";
extern char *STD_TEXTIO;
extern char *IEEE_P_3564397177;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
void ieee_p_3564397177_sub_1281154728_91900896(char *, char *, char *, char *, char *, unsigned char , int );
void ieee_p_3564397177_sub_1496949865_91900896(char *, char *, char *, unsigned char , unsigned char , int );
void ieee_p_3564397177_sub_2743816878_91900896(char *, char *, char *, char *);
void ieee_p_3564397177_sub_2889341154_91900896(char *, char *, char *, char *, char *);


static void work_a_3671711236_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 2732U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 3116);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 1408U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2632);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3116);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 1408U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2632);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_3671711236_2372691052_p_1(char *t0)
{
    char t5[16];
    char t10[24];
    char t11[24];
    char t12[24];
    char t13[24];
    char t14[24];
    char t15[24];
    char t16[24];
    char t20[8];
    char t21[8];
    char t22[8];
    char t23[24];
    char t25[24];
    char t26[8];
    char t27[8];
    char t28[8];
    char t29[24];
    char t30[24];
    char t32[8];
    char t33[8];
    char t34[8];
    char t35[24];
    char t36[24];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t17;
    unsigned char t18;
    int64 t19;
    unsigned char t24;
    int64 t31;

LAB0:    t1 = (t0 + 2876U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2136U);
    t3 = (t0 + 6997);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 1;
    t7 = (t6 + 4U);
    *((int *)t7) = 35;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (35 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    std_textio_file_open1(t2, t3, t5, (unsigned char)0);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 2072U);
    t3 = (t0 + 7032);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 1;
    t7 = (t6 + 4U);
    *((int *)t7) = 34;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (34 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    std_textio_file_open1(t2, t3, t5, (unsigned char)1);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 7066);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t10, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t10, t6, (unsigned char)0, t8);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 7083);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t11, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t11, t6, (unsigned char)0, t8);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 7100);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t12, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t12, t6, (unsigned char)0, t8);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 7117);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t13, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t13, t6, (unsigned char)0, t8);
    xsi_set_current_line(98, ng0);
    t2 = (t0 + 7134);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t14, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 2);
    std_textio_write7(STD_TEXTIO, t2, t3, t14, t6, (unsigned char)0, t8);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 7151);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(101, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t15, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t15, t6, (unsigned char)0, t8);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 7168);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t16, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t16, t6, (unsigned char)0, t8);
    xsi_set_current_line(104, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2072U);
    t4 = (t0 + 2240U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2136U);
    t4 = (t0 + 2280U);
    std_textio_readline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1476U);
    t6 = *((char **)t4);
    t4 = (t0 + 6728U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 1476U);
    t3 = *((char **)t2);
    t2 = (t0 + 3152);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 5U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(113, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1544U);
    t6 = *((char **)t4);
    t4 = (t0 + 6744U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(114, ng0);
    t2 = (t0 + 1544U);
    t3 = *((char **)t2);
    t2 = (t0 + 3188);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 4U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1612U);
    t6 = *((char **)t4);
    t4 = (t0 + 6760U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 1612U);
    t3 = *((char **)t2);
    t2 = (t0 + 3224);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 4U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(119, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1680U);
    t6 = *((char **)t4);
    t4 = (t6 + 0);
    ieee_p_3564397177_sub_2743816878_91900896(IEEE_P_3564397177, t2, t3, t4);
    xsi_set_current_line(120, ng0);
    t2 = (t0 + 1680U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 3260);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = t18;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(122, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1748U);
    t6 = *((char **)t4);
    t4 = (t6 + 0);
    ieee_p_3564397177_sub_2743816878_91900896(IEEE_P_3564397177, t2, t3, t4);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 1748U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 3296);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = t18;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(125, ng0);
    t19 = (57 * 1000LL);
    t2 = (t0 + 2776);
    xsi_process_wait(t2, t19);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(127, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1476U);
    t6 = *((char **)t4);
    memcpy(t20, t6, 5U);
    t4 = (t0 + 6728U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t20, t4, (unsigned char)0, 6);
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1544U);
    t6 = *((char **)t4);
    memcpy(t21, t6, 4U);
    t4 = (t0 + 6744U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t21, t4, (unsigned char)0, 17);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1612U);
    t6 = *((char **)t4);
    memcpy(t22, t6, 4U);
    t4 = (t0 + 6760U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t22, t4, (unsigned char)0, 18);
    xsi_set_current_line(130, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1680U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(131, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1748U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(133, ng0);
    t2 = (t0 + 1236U);
    t3 = *((char **)t2);
    t2 = (t0 + 1884U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    memcpy(t2, t3, 20U);
    xsi_set_current_line(134, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1884U);
    t6 = *((char **)t4);
    memcpy(t23, t6, 20U);
    t4 = (t0 + 6776U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t23, t4, (unsigned char)0, 32);
    xsi_set_current_line(136, ng0);
    t19 = (2 * 1000LL);
    t2 = (t0 + 2776);
    xsi_process_wait(t2, t19);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(137, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 1816U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    *((unsigned char *)t2) = t18;
    xsi_set_current_line(139, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t24 = (t18 == (unsigned char)3);
    if (t24 != 0)
        goto LAB12;

LAB14:    xsi_set_current_line(142, ng0);
    t2 = (t0 + 7202);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);

LAB13:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t25, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t25, t6, (unsigned char)0, t8);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2072U);
    t4 = (t0 + 2240U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(148, ng0);

LAB15:    t2 = (t0 + 2136U);
    t18 = std_textio_endfile(t2);
    t24 = (!(t18));
    if (t24 != 0)
        goto LAB16;

LAB18:    xsi_set_current_line(214, ng0);
    t2 = (t0 + 2136U);
    std_textio_file_close(t2);
    xsi_set_current_line(215, ng0);
    t2 = (t0 + 2072U);
    std_textio_file_close(t2);
    xsi_set_current_line(217, ng0);

LAB39:    *((char **)t1) = &&LAB40;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(140, ng0);
    t2 = (t0 + 7185);
    t6 = (t0 + 2404U);
    t7 = (t6 + 36U);
    t17 = *((char **)t7);
    t7 = (t17 + 0);
    memcpy(t7, t2, 17U);
    goto LAB13;

LAB16:    xsi_set_current_line(150, ng0);
    t3 = (t0 + 2776);
    t4 = (t0 + 2136U);
    t6 = (t0 + 2280U);
    std_textio_readline(STD_TEXTIO, t3, t4, t6);
    xsi_set_current_line(152, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1476U);
    t6 = *((char **)t4);
    t4 = (t0 + 6728U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 1476U);
    t3 = *((char **)t2);
    t2 = (t0 + 3152);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 5U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1544U);
    t6 = *((char **)t4);
    t4 = (t0 + 6744U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 1544U);
    t3 = *((char **)t2);
    t2 = (t0 + 3188);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 4U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(158, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1612U);
    t6 = *((char **)t4);
    t4 = (t0 + 6760U);
    ieee_p_3564397177_sub_2889341154_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 1612U);
    t3 = *((char **)t2);
    t2 = (t0 + 3224);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    memcpy(t17, t3, 4U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(161, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1680U);
    t6 = *((char **)t4);
    t4 = (t6 + 0);
    ieee_p_3564397177_sub_2743816878_91900896(IEEE_P_3564397177, t2, t3, t4);
    xsi_set_current_line(162, ng0);
    t2 = (t0 + 1680U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 3260);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = t18;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(164, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2280U);
    t4 = (t0 + 1748U);
    t6 = *((char **)t4);
    t4 = (t6 + 0);
    ieee_p_3564397177_sub_2743816878_91900896(IEEE_P_3564397177, t2, t3, t4);
    xsi_set_current_line(165, ng0);
    t2 = (t0 + 1748U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 3296);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = t18;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(167, ng0);

LAB21:    t2 = (t0 + 3072);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB22;
    goto LAB1;

LAB17:;
LAB19:    t4 = (t0 + 3072);
    *((int *)t4) = 0;
    xsi_set_current_line(169, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1476U);
    t6 = *((char **)t4);
    memcpy(t26, t6, 5U);
    t4 = (t0 + 6728U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t26, t4, (unsigned char)0, 6);
    xsi_set_current_line(170, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1544U);
    t6 = *((char **)t4);
    memcpy(t27, t6, 4U);
    t4 = (t0 + 6744U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t27, t4, (unsigned char)0, 17);
    xsi_set_current_line(171, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1612U);
    t6 = *((char **)t4);
    memcpy(t28, t6, 4U);
    t4 = (t0 + 6760U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t28, t4, (unsigned char)0, 18);
    xsi_set_current_line(172, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1680U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(173, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1748U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(175, ng0);
    t19 = (1 * 1000LL);
    t2 = (t0 + 2776);
    xsi_process_wait(t2, t19);

LAB25:    *((char **)t1) = &&LAB26;
    goto LAB1;

LAB20:    t3 = (t0 + 1028U);
    t18 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t18 == 1)
        goto LAB19;
    else
        goto LAB21;

LAB22:    goto LAB20;

LAB23:    xsi_set_current_line(177, ng0);
    t2 = (t0 + 1236U);
    t3 = *((char **)t2);
    t2 = (t0 + 1884U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    memcpy(t2, t3, 20U);
    xsi_set_current_line(178, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1884U);
    t6 = *((char **)t4);
    memcpy(t29, t6, 20U);
    t4 = (t0 + 6776U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t29, t4, (unsigned char)0, 32);
    xsi_set_current_line(180, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 1816U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    *((unsigned char *)t2) = t18;
    xsi_set_current_line(182, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t24 = (t18 == (unsigned char)3);
    if (t24 != 0)
        goto LAB27;

LAB29:    xsi_set_current_line(185, ng0);
    t2 = (t0 + 7236);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);

LAB28:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t30, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t30, t6, (unsigned char)0, t8);
    xsi_set_current_line(189, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2072U);
    t4 = (t0 + 2240U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(191, ng0);
    t2 = (t0 + 1408U);
    t3 = *((char **)t2);
    t19 = *((int64 *)t3);
    t31 = (t19 / 2);
    t2 = (t0 + 2776);
    xsi_process_wait(t2, t31);

LAB32:    *((char **)t1) = &&LAB33;
    goto LAB1;

LAB24:    goto LAB23;

LAB26:    goto LAB24;

LAB27:    xsi_set_current_line(183, ng0);
    t2 = (t0 + 7219);
    t6 = (t0 + 2404U);
    t7 = (t6 + 36U);
    t17 = *((char **)t7);
    t7 = (t17 + 0);
    memcpy(t7, t2, 17U);
    goto LAB28;

LAB30:    xsi_set_current_line(193, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1476U);
    t6 = *((char **)t4);
    memcpy(t32, t6, 5U);
    t4 = (t0 + 6728U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t32, t4, (unsigned char)0, 6);
    xsi_set_current_line(194, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1544U);
    t6 = *((char **)t4);
    memcpy(t33, t6, 4U);
    t4 = (t0 + 6744U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t33, t4, (unsigned char)0, 17);
    xsi_set_current_line(195, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1612U);
    t6 = *((char **)t4);
    memcpy(t34, t6, 4U);
    t4 = (t0 + 6760U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t34, t4, (unsigned char)0, 18);
    xsi_set_current_line(196, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1680U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(197, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1748U);
    t6 = *((char **)t4);
    t18 = *((unsigned char *)t6);
    ieee_p_3564397177_sub_1496949865_91900896(IEEE_P_3564397177, t2, t3, t18, (unsigned char)0, 18);
    xsi_set_current_line(199, ng0);
    t2 = (t0 + 1236U);
    t3 = *((char **)t2);
    t2 = (t0 + 1884U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    memcpy(t2, t3, 20U);
    xsi_set_current_line(200, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 1884U);
    t6 = *((char **)t4);
    memcpy(t35, t6, 20U);
    t4 = (t0 + 6776U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t35, t4, (unsigned char)0, 32);
    xsi_set_current_line(202, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t2 = (t0 + 1816U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    *((unsigned char *)t2) = t18;
    xsi_set_current_line(203, ng0);
    t2 = (t0 + 1144U);
    t3 = *((char **)t2);
    t18 = *((unsigned char *)t3);
    t24 = (t18 == (unsigned char)3);
    if (t24 != 0)
        goto LAB34;

LAB36:    xsi_set_current_line(206, ng0);
    t2 = (t0 + 7270);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 17U);

LAB35:    xsi_set_current_line(209, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2240U);
    t4 = (t0 + 2404U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t36, t7, 17U);
    t6 = (t0 + 6792U);
    t8 = (17U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t36, t6, (unsigned char)0, t8);
    xsi_set_current_line(210, ng0);
    t2 = (t0 + 2776);
    t3 = (t0 + 2072U);
    t4 = (t0 + 2240U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    goto LAB15;

LAB31:    goto LAB30;

LAB33:    goto LAB31;

LAB34:    xsi_set_current_line(204, ng0);
    t2 = (t0 + 7253);
    t6 = (t0 + 2404U);
    t7 = (t6 + 36U);
    t17 = *((char **)t7);
    t7 = (t17 + 0);
    memcpy(t7, t2, 17U);
    goto LAB35;

LAB37:    goto LAB2;

LAB38:    goto LAB37;

LAB40:    goto LAB38;

}


extern void work_a_3671711236_2372691052_init()
{
	static char *pe[] = {(void *)work_a_3671711236_2372691052_p_0,(void *)work_a_3671711236_2372691052_p_1};
	xsi_register_didat("work_a_3671711236_2372691052", "isim/TB_isim_beh.exe.sim/work/a_3671711236_2372691052.didat");
	xsi_register_executes(pe);
}
