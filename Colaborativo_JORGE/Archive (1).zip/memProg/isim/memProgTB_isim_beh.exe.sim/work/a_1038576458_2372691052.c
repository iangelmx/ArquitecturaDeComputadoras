/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vboxsrv/Downloads/Arqui/memProg/memProgTB.vhd";
extern char *STD_TEXTIO;
extern char *IEEE_P_3564397177;

void ieee_p_3564397177_sub_1281154728_91900896(char *, char *, char *, char *, char *, unsigned char , int );
void ieee_p_3564397177_sub_3205433008_91900896(char *, char *, char *, char *, char *, unsigned char , int );
void ieee_p_3564397177_sub_3988856810_91900896(char *, char *, char *, char *, char *);


static void work_a_1038576458_2372691052_p_0(char *t0)
{
    char t5[16];
    char t10[8];
    char t11[8];
    char t12[8];
    char t13[8];
    char t14[8];
    char t15[8];
    char t16[8];
    char t20[16];
    char t21[8];
    char t25[8];
    char t27[8];
    char t28[8];
    char t29[8];
    char t30[8];
    char t31[8];
    char t32[8];
    char t33[8];
    char t34[8];
    char t35[8];
    char t36[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    int64 t17;
    int t18;
    char *t19;
    int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t26;

LAB0:    t1 = (t0 + 1856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 1176U);
    t3 = (t0 + 4216);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 1;
    t7 = (t6 + 4U);
    *((int *)t7) = 11;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (11 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    std_textio_file_open1(t2, t3, t5, (unsigned char)0);
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1112U);
    t3 = (t0 + 4227);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 1;
    t7 = (t6 + 4U);
    *((int *)t7) = 10;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (10 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    std_textio_file_open1(t2, t3, t5, (unsigned char)1);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 4237);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t10, t7, 8U);
    t6 = (t0 + 4004U);
    std_textio_write7(STD_TEXTIO, t2, t3, t10, t6, (unsigned char)0, 8);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 4245);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t11, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t11, t6, (unsigned char)0, t8);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 4253);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t12, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t12, t6, (unsigned char)0, t8);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 4261);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t13, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t13, t6, (unsigned char)0, t8);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 4269);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t14, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t14, t6, (unsigned char)0, t8);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 4277);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t15, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t15, t6, (unsigned char)0, t8);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 4285);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 8U);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1444U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t16, t7, 8U);
    t6 = (t0 + 4004U);
    t8 = (8U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t16, t6, (unsigned char)0, t8);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1112U);
    t4 = (t0 + 1280U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(71, ng0);
    t17 = (10 * 1000LL);
    t2 = (t0 + 1756);
    xsi_process_wait(t2, t17);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 4293);
    *((int *)t2) = 1;
    t3 = (t0 + 4297);
    *((int *)t3) = 10;
    t8 = 1;
    t18 = 10;

LAB8:    if (t8 <= t18)
        goto LAB9;

LAB11:    xsi_set_current_line(101, ng0);
    t2 = (t0 + 1176U);
    std_textio_file_close(t2);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 1112U);
    std_textio_file_close(t2);
    xsi_set_current_line(103, ng0);

LAB19:    *((char **)t1) = &&LAB20;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(74, ng0);
    t4 = (t0 + 1756);
    t6 = (t0 + 1176U);
    t7 = (t0 + 1320U);
    std_textio_readline(STD_TEXTIO, t4, t6, t7);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1320U);
    t4 = (t0 + 924U);
    t6 = *((char **)t4);
    t4 = (t0 + 3988U);
    ieee_p_3564397177_sub_3988856810_91900896(IEEE_P_3564397177, t2, t3, t6, t4);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 924U);
    t3 = *((char **)t2);
    t2 = (t0 + 2088);
    t4 = (t2 + 32U);
    t6 = *((char **)t4);
    t7 = (t6 + 40U);
    t19 = *((char **)t7);
    memcpy(t19, t3, 12U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(78, ng0);
    t17 = (10 * 1000LL);
    t2 = (t0 + 1756);
    xsi_process_wait(t2, t17);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB10:    t2 = (t0 + 4293);
    t8 = *((int *)t2);
    t3 = (t0 + 4297);
    t18 = *((int *)t3);
    if (t8 == t18)
        goto LAB11;

LAB16:    t22 = (t8 + 1);
    t8 = t22;
    t4 = (t0 + 4293);
    *((int *)t4) = t8;
    goto LAB8;

LAB12:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t2 = (t0 + 856U);
    t4 = *((char **)t2);
    t2 = (t4 + 0);
    memcpy(t2, t3, 25U);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 924U);
    t6 = *((char **)t4);
    memcpy(t20, t6, 12U);
    t4 = (t0 + 3988U);
    ieee_p_3564397177_sub_3205433008_91900896(IEEE_P_3564397177, t2, t3, t20, t4, (unsigned char)0, 4);
    xsi_set_current_line(83, ng0);
    t2 = (t0 + 4301);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    memcpy(t6, t2, 4U);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t21, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t21, t6, (unsigned char)0, t22);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 24);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t25, t4, 5U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 24;
    t19 = (t7 + 4U);
    *((int *)t19) = 20;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (20 - 24);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t25, t5, (unsigned char)0, 5);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t27, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t27, t6, (unsigned char)0, t22);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 19);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t28, t4, 4U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 19;
    t19 = (t7 + 4U);
    *((int *)t19) = 16;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (16 - 19);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t28, t5, (unsigned char)0, 4);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t29, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t29, t6, (unsigned char)0, t22);
    xsi_set_current_line(89, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 15);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t30, t4, 4U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 15;
    t19 = (t7 + 4U);
    *((int *)t19) = 12;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (12 - 15);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t30, t5, (unsigned char)0, 4);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t31, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t31, t6, (unsigned char)0, t22);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 11);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t32, t4, 4U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 11;
    t19 = (t7 + 4U);
    *((int *)t19) = 8;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (8 - 11);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t32, t5, (unsigned char)0, 4);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t33, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t33, t6, (unsigned char)0, t22);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 7);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t34, t4, 4U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 7;
    t19 = (t7 + 4U);
    *((int *)t19) = 4;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (4 - 7);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t34, t5, (unsigned char)0, 4);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 1528U);
    t6 = (t4 + 36U);
    t7 = *((char **)t6);
    memcpy(t35, t7, 4U);
    t6 = (t0 + 4020U);
    t22 = (4U + 1);
    std_textio_write7(STD_TEXTIO, t2, t3, t35, t6, (unsigned char)0, t22);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1280U);
    t4 = (t0 + 856U);
    t6 = *((char **)t4);
    t9 = (24 - 3);
    t23 = (t9 * 1U);
    t24 = (0 + t23);
    t4 = (t6 + t24);
    memcpy(t36, t4, 4U);
    t7 = (t5 + 0U);
    t19 = (t7 + 0U);
    *((int *)t19) = 3;
    t19 = (t7 + 4U);
    *((int *)t19) = 0;
    t19 = (t7 + 8U);
    *((int *)t19) = -1;
    t22 = (0 - 3);
    t26 = (t22 * -1);
    t26 = (t26 + 1);
    t19 = (t7 + 12U);
    *((unsigned int *)t19) = t26;
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t36, t5, (unsigned char)0, 4);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 1756);
    t3 = (t0 + 1112U);
    t4 = (t0 + 1280U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    goto LAB10;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB17:    goto LAB2;

LAB18:    goto LAB17;

LAB20:    goto LAB18;

}


extern void work_a_1038576458_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1038576458_2372691052_p_0};
	xsi_register_didat("work_a_1038576458_2372691052", "isim/memProgTB_isim_beh.exe.sim/work/a_1038576458_2372691052.didat");
	xsi_register_executes(pe);
}
